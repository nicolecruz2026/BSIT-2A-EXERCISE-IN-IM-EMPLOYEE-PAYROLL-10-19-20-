﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.txtHourlySalary = New System.Windows.Forms.TextBox()
        Me.txtEmployeeNbr = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.dptEndDate = New System.Windows.Forms.DateTimePicker()
        Me.dptStartingDate = New System.Windows.Forms.DateTimePicker()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.txtSaturday2 = New System.Windows.Forms.TextBox()
        Me.txtSaturday1 = New System.Windows.Forms.TextBox()
        Me.txtFriday2 = New System.Windows.Forms.TextBox()
        Me.txtFriday1 = New System.Windows.Forms.TextBox()
        Me.txtThursday2 = New System.Windows.Forms.TextBox()
        Me.txtThursday1 = New System.Windows.Forms.TextBox()
        Me.txtSunday2 = New System.Windows.Forms.TextBox()
        Me.txtSunday1 = New System.Windows.Forms.TextBox()
        Me.txtWednesday2 = New System.Windows.Forms.TextBox()
        Me.txtWednesday1 = New System.Windows.Forms.TextBox()
        Me.txtTuesday2 = New System.Windows.Forms.TextBox()
        Me.txtMonday2 = New System.Windows.Forms.TextBox()
        Me.txtTuesday1 = New System.Windows.Forms.TextBox()
        Me.txtMonday1 = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.txtNetPay = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.btnProcessIt = New System.Windows.Forms.Button()
        Me.txtRegularAmount = New System.Windows.Forms.TextBox()
        Me.txtRegularHours = New System.Windows.Forms.TextBox()
        Me.txtOvertimeHours = New System.Windows.Forms.TextBox()
        Me.txtOvertimeAmount = New System.Windows.Forms.TextBox()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.txtHourlySalary)
        Me.GroupBox1.Controls.Add(Me.txtEmployeeNbr)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Location = New System.Drawing.Point(14, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(228, 149)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Employee Identification"
        '
        'txtHourlySalary
        '
        Me.txtHourlySalary.Location = New System.Drawing.Point(122, 91)
        Me.txtHourlySalary.Name = "txtHourlySalary"
        Me.txtHourlySalary.Size = New System.Drawing.Size(96, 22)
        Me.txtHourlySalary.TabIndex = 1
        '
        'txtEmployeeNbr
        '
        Me.txtEmployeeNbr.Location = New System.Drawing.Point(122, 37)
        Me.txtEmployeeNbr.Name = "txtEmployeeNbr"
        Me.txtEmployeeNbr.Size = New System.Drawing.Size(96, 22)
        Me.txtEmployeeNbr.TabIndex = 1
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(6, 96)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(97, 17)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "Hourly Salary:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(6, 40)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(86, 17)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Employee #:"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.dptEndDate)
        Me.GroupBox2.Controls.Add(Me.dptStartingDate)
        Me.GroupBox2.Controls.Add(Me.Label4)
        Me.GroupBox2.Controls.Add(Me.Label3)
        Me.GroupBox2.Location = New System.Drawing.Point(248, 12)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(454, 149)
        Me.GroupBox2.TabIndex = 1
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Time Period"
        '
        'dptEndDate
        '
        Me.dptEndDate.Location = New System.Drawing.Point(122, 96)
        Me.dptEndDate.Name = "dptEndDate"
        Me.dptEndDate.Size = New System.Drawing.Size(315, 22)
        Me.dptEndDate.TabIndex = 1
        '
        'dptStartingDate
        '
        Me.dptStartingDate.Location = New System.Drawing.Point(124, 37)
        Me.dptStartingDate.Name = "dptStartingDate"
        Me.dptStartingDate.Size = New System.Drawing.Size(315, 22)
        Me.dptStartingDate.TabIndex = 1
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(6, 96)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(75, 17)
        Me.Label4.TabIndex = 0
        Me.Label4.Text = "End Date :"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(6, 40)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(99, 17)
        Me.Label3.TabIndex = 0
        Me.Label3.Text = "Starting Date :"
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.Label18)
        Me.GroupBox3.Controls.Add(Me.Label17)
        Me.GroupBox3.Controls.Add(Me.Label16)
        Me.GroupBox3.Controls.Add(Me.Label15)
        Me.GroupBox3.Controls.Add(Me.Label14)
        Me.GroupBox3.Controls.Add(Me.Label13)
        Me.GroupBox3.Controls.Add(Me.Label12)
        Me.GroupBox3.Controls.Add(Me.txtSaturday2)
        Me.GroupBox3.Controls.Add(Me.txtSaturday1)
        Me.GroupBox3.Controls.Add(Me.txtFriday2)
        Me.GroupBox3.Controls.Add(Me.txtFriday1)
        Me.GroupBox3.Controls.Add(Me.txtThursday2)
        Me.GroupBox3.Controls.Add(Me.txtThursday1)
        Me.GroupBox3.Controls.Add(Me.txtSunday2)
        Me.GroupBox3.Controls.Add(Me.txtSunday1)
        Me.GroupBox3.Controls.Add(Me.txtWednesday2)
        Me.GroupBox3.Controls.Add(Me.txtWednesday1)
        Me.GroupBox3.Controls.Add(Me.txtTuesday2)
        Me.GroupBox3.Controls.Add(Me.txtMonday2)
        Me.GroupBox3.Controls.Add(Me.txtTuesday1)
        Me.GroupBox3.Controls.Add(Me.txtMonday1)
        Me.GroupBox3.Controls.Add(Me.Label6)
        Me.GroupBox3.Controls.Add(Me.Label5)
        Me.GroupBox3.Location = New System.Drawing.Point(14, 167)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(688, 144)
        Me.GroupBox3.TabIndex = 1
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Time Sheet"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(596, 18)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(56, 17)
        Me.Label18.TabIndex = 2
        Me.Label18.Text = "Sunday"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(515, 18)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(65, 17)
        Me.Label17.TabIndex = 2
        Me.Label17.Text = "Saturday"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(437, 18)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(47, 17)
        Me.Label16.TabIndex = 2
        Me.Label16.Text = "Friday"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(355, 18)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(68, 17)
        Me.Label15.TabIndex = 2
        Me.Label15.Text = "Thursday"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(272, 18)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(83, 17)
        Me.Label14.TabIndex = 2
        Me.Label14.Text = "Wednesday"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(191, 18)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(63, 17)
        Me.Label13.TabIndex = 2
        Me.Label13.Text = "Tuesday"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(110, 18)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(58, 17)
        Me.Label12.TabIndex = 2
        Me.Label12.Text = "Monday"
        '
        'txtSaturday2
        '
        Me.txtSaturday2.Location = New System.Drawing.Point(518, 88)
        Me.txtSaturday2.Name = "txtSaturday2"
        Me.txtSaturday2.Size = New System.Drawing.Size(75, 22)
        Me.txtSaturday2.TabIndex = 1
        Me.txtSaturday2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtSaturday1
        '
        Me.txtSaturday1.Location = New System.Drawing.Point(518, 45)
        Me.txtSaturday1.Name = "txtSaturday1"
        Me.txtSaturday1.Size = New System.Drawing.Size(75, 22)
        Me.txtSaturday1.TabIndex = 1
        Me.txtSaturday1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtFriday2
        '
        Me.txtFriday2.Location = New System.Drawing.Point(437, 88)
        Me.txtFriday2.Name = "txtFriday2"
        Me.txtFriday2.Size = New System.Drawing.Size(75, 22)
        Me.txtFriday2.TabIndex = 1
        Me.txtFriday2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtFriday1
        '
        Me.txtFriday1.Location = New System.Drawing.Point(437, 45)
        Me.txtFriday1.Name = "txtFriday1"
        Me.txtFriday1.Size = New System.Drawing.Size(75, 22)
        Me.txtFriday1.TabIndex = 1
        Me.txtFriday1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtThursday2
        '
        Me.txtThursday2.Location = New System.Drawing.Point(356, 88)
        Me.txtThursday2.Name = "txtThursday2"
        Me.txtThursday2.Size = New System.Drawing.Size(75, 22)
        Me.txtThursday2.TabIndex = 1
        Me.txtThursday2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtThursday1
        '
        Me.txtThursday1.Location = New System.Drawing.Point(356, 45)
        Me.txtThursday1.Name = "txtThursday1"
        Me.txtThursday1.Size = New System.Drawing.Size(75, 22)
        Me.txtThursday1.TabIndex = 1
        Me.txtThursday1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtSunday2
        '
        Me.txtSunday2.Location = New System.Drawing.Point(599, 88)
        Me.txtSunday2.Name = "txtSunday2"
        Me.txtSunday2.Size = New System.Drawing.Size(75, 22)
        Me.txtSunday2.TabIndex = 1
        Me.txtSunday2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtSunday1
        '
        Me.txtSunday1.Location = New System.Drawing.Point(599, 45)
        Me.txtSunday1.Name = "txtSunday1"
        Me.txtSunday1.Size = New System.Drawing.Size(75, 22)
        Me.txtSunday1.TabIndex = 1
        Me.txtSunday1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtWednesday2
        '
        Me.txtWednesday2.Location = New System.Drawing.Point(275, 88)
        Me.txtWednesday2.Name = "txtWednesday2"
        Me.txtWednesday2.Size = New System.Drawing.Size(75, 22)
        Me.txtWednesday2.TabIndex = 1
        Me.txtWednesday2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtWednesday1
        '
        Me.txtWednesday1.Location = New System.Drawing.Point(275, 45)
        Me.txtWednesday1.Name = "txtWednesday1"
        Me.txtWednesday1.Size = New System.Drawing.Size(75, 22)
        Me.txtWednesday1.TabIndex = 1
        Me.txtWednesday1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtTuesday2
        '
        Me.txtTuesday2.Location = New System.Drawing.Point(194, 88)
        Me.txtTuesday2.Name = "txtTuesday2"
        Me.txtTuesday2.Size = New System.Drawing.Size(75, 22)
        Me.txtTuesday2.TabIndex = 1
        Me.txtTuesday2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtMonday2
        '
        Me.txtMonday2.Location = New System.Drawing.Point(113, 88)
        Me.txtMonday2.Name = "txtMonday2"
        Me.txtMonday2.Size = New System.Drawing.Size(75, 22)
        Me.txtMonday2.TabIndex = 1
        Me.txtMonday2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtTuesday1
        '
        Me.txtTuesday1.Location = New System.Drawing.Point(194, 45)
        Me.txtTuesday1.Name = "txtTuesday1"
        Me.txtTuesday1.Size = New System.Drawing.Size(75, 22)
        Me.txtTuesday1.TabIndex = 1
        Me.txtTuesday1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtMonday1
        '
        Me.txtMonday1.Location = New System.Drawing.Point(113, 45)
        Me.txtMonday1.Name = "txtMonday1"
        Me.txtMonday1.Size = New System.Drawing.Size(75, 22)
        Me.txtMonday1.TabIndex = 1
        Me.txtMonday1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(6, 93)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(96, 17)
        Me.Label6.TabIndex = 0
        Me.Label6.Text = "Second Week"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(6, 50)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(75, 17)
        Me.Label5.TabIndex = 0
        Me.Label5.Text = "First Week"
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.Button2)
        Me.GroupBox4.Controls.Add(Me.txtNetPay)
        Me.GroupBox4.Controls.Add(Me.Label11)
        Me.GroupBox4.Controls.Add(Me.Label10)
        Me.GroupBox4.Controls.Add(Me.Label9)
        Me.GroupBox4.Controls.Add(Me.Label8)
        Me.GroupBox4.Controls.Add(Me.Label7)
        Me.GroupBox4.Controls.Add(Me.btnProcessIt)
        Me.GroupBox4.Controls.Add(Me.txtRegularAmount)
        Me.GroupBox4.Controls.Add(Me.txtRegularHours)
        Me.GroupBox4.Controls.Add(Me.txtOvertimeHours)
        Me.GroupBox4.Controls.Add(Me.txtOvertimeAmount)
        Me.GroupBox4.Location = New System.Drawing.Point(14, 317)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(688, 111)
        Me.GroupBox4.TabIndex = 1
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Payroll Processing"
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(559, 69)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(92, 25)
        Me.Button2.TabIndex = 6
        Me.Button2.Text = "Close"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'txtNetPay
        '
        Me.txtNetPay.Location = New System.Drawing.Point(559, 41)
        Me.txtNetPay.Name = "txtNetPay"
        Me.txtNetPay.Size = New System.Drawing.Size(93, 22)
        Me.txtNetPay.TabIndex = 5
        Me.txtNetPay.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(453, 41)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(100, 17)
        Me.Label11.TabIndex = 4
        Me.Label11.Text = "Total Earnings"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(353, 18)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(56, 17)
        Me.Label10.TabIndex = 4
        Me.Label10.Text = "Amount"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(255, 18)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(46, 17)
        Me.Label9.TabIndex = 4
        Me.Label9.Text = "Hours"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(163, 78)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(65, 17)
        Me.Label8.TabIndex = 3
        Me.Label8.Text = "Overtime"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(163, 38)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(58, 17)
        Me.Label7.TabIndex = 3
        Me.Label7.Text = "Regular"
        '
        'btnProcessIt
        '
        Me.btnProcessIt.Location = New System.Drawing.Point(22, 38)
        Me.btnProcessIt.Name = "btnProcessIt"
        Me.btnProcessIt.Size = New System.Drawing.Size(100, 47)
        Me.btnProcessIt.TabIndex = 2
        Me.btnProcessIt.Text = "Process It"
        Me.btnProcessIt.UseVisualStyleBackColor = True
        '
        'txtRegularAmount
        '
        Me.txtRegularAmount.Location = New System.Drawing.Point(339, 38)
        Me.txtRegularAmount.Name = "txtRegularAmount"
        Me.txtRegularAmount.Size = New System.Drawing.Size(75, 22)
        Me.txtRegularAmount.TabIndex = 1
        Me.txtRegularAmount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtRegularHours
        '
        Me.txtRegularHours.Location = New System.Drawing.Point(243, 38)
        Me.txtRegularHours.Name = "txtRegularHours"
        Me.txtRegularHours.Size = New System.Drawing.Size(75, 22)
        Me.txtRegularHours.TabIndex = 1
        Me.txtRegularHours.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtOvertimeHours
        '
        Me.txtOvertimeHours.Location = New System.Drawing.Point(243, 78)
        Me.txtOvertimeHours.Name = "txtOvertimeHours"
        Me.txtOvertimeHours.Size = New System.Drawing.Size(75, 22)
        Me.txtOvertimeHours.TabIndex = 1
        Me.txtOvertimeHours.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtOvertimeAmount
        '
        Me.txtOvertimeAmount.Location = New System.Drawing.Point(339, 78)
        Me.txtOvertimeAmount.Name = "txtOvertimeAmount"
        Me.txtOvertimeAmount.Size = New System.Drawing.Size(75, 22)
        Me.txtOvertimeAmount.TabIndex = 1
        Me.txtOvertimeAmount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(714, 440)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "Form1"
        Me.Text = "Georgetown Cleaning Service - Employee Payroll"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents txtHourlySalary As System.Windows.Forms.TextBox
    Friend WithEvents txtEmployeeNbr As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents dptEndDate As System.Windows.Forms.DateTimePicker
    Friend WithEvents dptStartingDate As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents txtSaturday2 As System.Windows.Forms.TextBox
    Friend WithEvents txtSaturday1 As System.Windows.Forms.TextBox
    Friend WithEvents txtFriday2 As System.Windows.Forms.TextBox
    Friend WithEvents txtFriday1 As System.Windows.Forms.TextBox
    Friend WithEvents txtThursday2 As System.Windows.Forms.TextBox
    Friend WithEvents txtThursday1 As System.Windows.Forms.TextBox
    Friend WithEvents txtSunday2 As System.Windows.Forms.TextBox
    Friend WithEvents txtSunday1 As System.Windows.Forms.TextBox
    Friend WithEvents txtWednesday2 As System.Windows.Forms.TextBox
    Friend WithEvents txtWednesday1 As System.Windows.Forms.TextBox
    Friend WithEvents txtTuesday2 As System.Windows.Forms.TextBox
    Friend WithEvents txtMonday2 As System.Windows.Forms.TextBox
    Friend WithEvents txtTuesday1 As System.Windows.Forms.TextBox
    Friend WithEvents txtMonday1 As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents txtNetPay As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents btnProcessIt As System.Windows.Forms.Button
    Friend WithEvents txtRegularAmount As System.Windows.Forms.TextBox
    Friend WithEvents txtRegularHours As System.Windows.Forms.TextBox
    Friend WithEvents txtOvertimeHours As System.Windows.Forms.TextBox
    Friend WithEvents txtOvertimeAmount As System.Windows.Forms.TextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label

End Class
